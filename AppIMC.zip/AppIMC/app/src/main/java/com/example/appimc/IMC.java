package com.example.appimc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class IMC extends AppCompatActivity{
    EditText peso, altura;
    TextView resultado;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_imc);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                calculaImc();
            }
        });
    }
    private void calculaImc() {
        //Associar variáveis JAVA com os elementos do xml
        peso = findViewById(R.id.ctxpeso);
        altura = findViewById(R.id.ctxaltura);
        resultado = findViewById(R.id.ctxresultado);
        float imc,vp,va;
        //Recolher os dados das caixas de texto e guardar nas variáveis
        vp =Float.parseFloat(peso.getText().toString());
        va =Float.parseFloat(altura.getText().toString());
        //calcular o imc
        imc = vp/(va*va);
        //mostrar o resultado
        if (imc<18.5)
            resultado.setText(R.string.smsimc);
        else if (imc<25)
            resultado.setText(R.string.smsimc2);
        else if (imc<30)
            resultado.setText(R.string.smspeso3);
        else if (imc<35)
            resultado.setText(R.string.smsimc4);
        else if (imc<40)
            resultado.setText(R.string.smsimc5);
        else
            resultado.setText(R.string.smsimc6);
    }

}

